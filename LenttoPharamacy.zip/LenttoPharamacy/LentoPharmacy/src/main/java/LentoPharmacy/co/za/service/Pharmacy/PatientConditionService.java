package LentoPharmacy.co.za.service.Pharmacy;

import LentoPharmacy.co.za.domain.PatientCondition;
import LentoPharmacy.co.za.service.BaseService;

/**
 * Created by Zukile Ralarala 01/06/2018.
 */
public interface PatientConditionService extends BaseService<PatientCondition,Long>{

}
