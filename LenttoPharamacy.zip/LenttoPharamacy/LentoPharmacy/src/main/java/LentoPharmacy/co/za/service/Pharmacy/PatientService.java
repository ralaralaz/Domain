package LentoPharmacy.co.za.service.Pharmacy;

import LentoPharmacy.co.za.domain.Patient;
import LentoPharmacy.co.za.service.BaseService;

/**
 * Created by Zukile Ralarala 01/06/2018.
 */
public interface PatientService extends BaseService<Patient,Long> {

}
