package LentoPharmacy.co.za.service.Pharmacy;

import LentoPharmacy.co.za.domain.Conditions;
import LentoPharmacy.co.za.service.BaseService;

/**
 * Created by Zukile Ralarala 01/06/2018.
 */
public interface ConditionServices extends BaseService<Conditions,Long>{


}
