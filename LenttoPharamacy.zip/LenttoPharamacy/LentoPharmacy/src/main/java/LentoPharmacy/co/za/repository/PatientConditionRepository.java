package LentoPharmacy.co.za.repository;

import LentoPharmacy.co.za.domain.PatientCondition;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by Zukile Ralarala on 01/06/2018.
 */
public interface PatientConditionRepository extends CrudRepository<PatientCondition,Long> {

}
