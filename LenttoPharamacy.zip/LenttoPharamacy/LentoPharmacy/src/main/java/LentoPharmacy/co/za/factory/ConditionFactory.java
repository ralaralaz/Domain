package LentoPharmacy.co.za.factory;

/**
 * Created by Zukile Ralarala on 01/06/2018.
 */

import LentoPharmacy.co.za.domain.Conditions;
import LentoPharmacy.co.za.utility.KeyGenerator;

public class ConditionFactory {

    public static Conditions buildCondition(String conditionName){

        Conditions conditionFactory = new Conditions.Builder()
                 .conditionId(KeyGenerator.getEntityId())
                .conditionName(conditionName)
                .build();

        return conditionFactory;
    }

    public static Conditions updateCondition(long conditionId,String conditionName){

        Conditions conditionFactory = new Conditions.Builder()
                .conditionId(conditionId)
                .conditionName(conditionName)
                .build();

        return conditionFactory;
    }
}
