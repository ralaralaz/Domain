package LentoPharmacy.co.za.repository;

import LentoPharmacy.co.za.domain.Users;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by Zukile Ralarala on 01/06/2018.
 */
public interface UserRepository extends CrudRepository<Users, Long> {
}
