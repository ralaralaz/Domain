package LentoPharmacy.co.za.utility;

import java.security.SecureRandom;
/**
 * Created by Zukile Ralarala 01/06/2018.
 */
public class KeyGenerator {

    public static long getEntityId(){
        SecureRandom rand = new SecureRandom();
        long uniqueNo;

            uniqueNo = 100 + rand.nextInt(900);


        return uniqueNo;
    }
}
