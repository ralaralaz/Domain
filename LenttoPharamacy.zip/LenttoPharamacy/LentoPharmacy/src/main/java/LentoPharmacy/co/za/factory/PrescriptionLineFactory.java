package LentoPharmacy.co.za.factory;

import LentoPharmacy.co.za.domain.Prescriptionline;
import LentoPharmacy.co.za.utility.KeyGenerator;

/**
 * Created by Zukile Ralarala on 01/06/2018.
 */
public class PrescriptionLineFactory {

    public static Prescriptionline getPrescriptionLine(long prescription, String instructions,
                                                       long medicine, double price, int qauntity){

        Prescriptionline prescriptionline = new Prescriptionline.Builder()

                .lineID(KeyGenerator.getEntityId())
                .prescriptionID(prescription)
                .instructions(instructions)
                .price(price)
                .medicineID(medicine)
                .quantity(qauntity)
                .build();
        return prescriptionline;
    }
}
