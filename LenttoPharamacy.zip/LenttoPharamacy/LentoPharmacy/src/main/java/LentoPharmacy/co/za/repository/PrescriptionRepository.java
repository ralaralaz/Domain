package LentoPharmacy.co.za.repository;

import LentoPharmacy.co.za.domain.Prescription;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by Zukile Ralarala on 01/06/2018.
 */
public interface PrescriptionRepository extends CrudRepository<Prescription,Long>{

}
