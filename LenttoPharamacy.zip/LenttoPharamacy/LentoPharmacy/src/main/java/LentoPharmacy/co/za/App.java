package LentoPharmacy.co.za;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by Zukile Ralarala on 01/06/2018.
 */
@SpringBootApplication
public class App {

    public static void main(String[]args) throws Exception{
       SpringApplication.run(App.class,args);
    }
}
