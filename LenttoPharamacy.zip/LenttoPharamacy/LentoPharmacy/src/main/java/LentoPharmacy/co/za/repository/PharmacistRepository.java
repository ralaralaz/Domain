package LentoPharmacy.co.za.repository;

import LentoPharmacy.co.za.domain.Pharmacist;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by Zukile Ralarala on 01/06/2018.
 */
public interface PharmacistRepository extends CrudRepository<Pharmacist,Long> {

}
