package LentoPharmacy.co.za.factory;

import LentoPharmacy.co.za.domain.Prescription;
import LentoPharmacy.co.za.utility.KeyGenerator;

/**
 * Created by Zukile Ralarala on 01/06/2018.
 */
public class PrescriptionFactory {

    public static Prescription getPrecscription(String datedescription, String doctorID,
                                                long patient, long pharmacist){

        Prescription prescription = new Prescription.Builder()

                .prescriptionID(KeyGenerator.getEntityId())
                .prescriptionDate(datedescription)
                .doctorId(doctorID)
                .patientID(patient)
                .pharmacistID(pharmacist)
                .build();

        return prescription;
    }
}
