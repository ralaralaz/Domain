package LentoPharmacy.co.za.repository;

import LentoPharmacy.co.za.domain.Medicine;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by Zukile Ralarala on 01/06/2018.
 */
public interface MedicineRepository extends CrudRepository<Medicine,Long> {


}
